<?php
session_start();
include('config.php'); // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // MD5 hash password

    // Query to check the user's credentials
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Get user details from the result
        $user = mysqli_fetch_assoc($result);

        // Store session information
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        // Redirect based on user role
        if ($user['role'] == 'admin') {
            header('Loction:admin_dashboard.php'); // Redirect to admin dashboard
        } else {
            header('Location: user_dashboard.php'); // Redirect to user dashboard
        }
    } else {
        echo "Invalid login credentials!";
    }
}
?>
