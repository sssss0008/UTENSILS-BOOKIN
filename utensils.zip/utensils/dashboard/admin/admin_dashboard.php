<?php
session_start();
include('config.php'); // Include database connection

// Check if admin is logged in
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch users from the database
$users_query = "SELECT * FROM users";
$users_result = mysqli_query($conn, $users_query);

// Fetch products from the database
$products_query = "SELECT * FROM products";
$products_result = mysqli_query($conn, $products_query);

// Fetch user orders
$orders_query = "SELECT u.username, p.name, o.quantity, o.order_date 
                 FROM user_orders o
                 JOIN users u ON o.user_id = u.id
                 JOIN products p ON o.product_id = p.id";
$orders_result = mysqli_query($conn, $orders_query);

// Handle adding a user
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); // MD5 hash password
    $role = $_POST['role'];

    $query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')";
    mysqli_query($conn, $query);
}

// Handle deleting a user
if (isset($_GET['delete_user'])) {
    $user_id = $_GET['delete_user'];
    $query = "DELETE FROM users WHERE id = $user_id";
    mysqli_query($conn, $query);
}
?>
